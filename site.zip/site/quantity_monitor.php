<?php
// Include your existing config file
include 'config.php';

// Set headers for CORS and JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Function to send JSON response
function sendResponse($success, $data = [], $message = '') {
    $response = [
        'success' => $success,
        'timestamp' => date('Y-m-d H:i:s')
    ];
    
    if ($message) {
        $response['message'] = $message;
    }
    
    if (!empty($data)) {
        $response = array_merge($response, $data);
    }
    
    echo json_encode($response);
    exit;
}

try {
    // Check if database connection is successful
    if ($conn->connect_error) {
        sendResponse(false, [], 'Database connection failed: ' . $conn->connect_error);
    }
    
    // Get current quantities of products 5,6,7,8
    $stmt = $conn->prepare("SELECT id, name, description, price, quantity, image FROM products WHERE id IN (5,6,7,8) ORDER BY id");
    
    if (!$stmt) {
        sendResponse(false, [], 'Prepare statement failed: ' . $conn->error);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $products = [];
    $motor_pins = [
        5 => 2,   // Product ID 5 -> GPIO 2 (D2)
        6 => 4,   // Product ID 6 -> GPIO 4 (D4)
        7 => 16,  // Product ID 7 -> GPIO 16 (D16)
        8 => 17   // Product ID 8 -> GPIO 17 (D17)
    ];
    
    while ($row = $result->fetch_assoc()) {
        // Build full image URL if image exists
        $imageUrl = '';
        if (!empty($row['image'])) {
            $imageUrl = BASE_URL . 'uploads/' . $row['image'];
        }
        
        $products[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'description' => $row['description'],
            'price' => (float)$row['price'],
            'quantity' => (int)$row['quantity'],
            'image' => $imageUrl,
            'motor_pin' => $motor_pins[$row['id']] ?? 0
        ];
    }
    
    $stmt->close();
    
    // Send successful response
    sendResponse(true, [
        'products' => $products,
        'total_products' => count($products),
        'motor_mapping' => $motor_pins
    ], 'Product quantities retrieved successfully');
    
} catch (Exception $e) {
    // Log error for debugging
    error_log("Quantity monitor error: " . $e->getMessage());
    
    sendResponse(false, [], 'Server error: ' . $e->getMessage());
}

// Close database connection
if (isset($conn)) {
    $conn->close();
}
?>
<?php
require 'config1.php';
requireLogin();

// Calculate sales statistics
$total_sales = $conn->query("SELECT SUM(price) as total FROM products")->fetch_assoc()['total'] ?? 0;

// Calculate total products sold (this is an approximation since we don't have sales table)
$initial_quantities = [
    'Coke' => 15,
    'Chips' => 8,
    'Water' => 20,
    'Biscuit' => 5
];

$total_products_sold = 0;
$product_sales_data = [];

$products = $conn->query("SELECT * FROM products");
while($product = $products->fetch_assoc()) {
    $initial_qty = $initial_quantities[$product['name']] ?? $product['quantity'];
    $sold = $initial_qty - $product['quantity'];
    $revenue = $sold * $product['price'];
    
    $total_products_sold += $sold;
    
    $product_sales_data[] = [
        'name' => $product['name'],
        'price' => $product['price'],
        'current_stock' => $product['quantity'],
        'initial_stock' => $initial_qty,
        'sold' => $sold,
        'revenue' => $revenue
    ];
}

// Sort by revenue descending
usort($product_sales_data, function($a, $b) {
    return $b['revenue'] - $a['revenue'];
});

// Get recent user activity (approximated)
$recent_users = $conn->query("SELECT name, phone, balance, created_at FROM users ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Report - Vending Machine</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
        }
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid #34495e;
            margin-bottom: 20px;
        }
        .sidebar-header h2 {
            color: #3498db;
        }
        .nav-links {
            list-style: none;
        }
        .nav-links li a {
            display: block;
            padding: 15px 20px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
        }
        .nav-links li a:hover, .nav-links li a.active {
            background: #34495e;
            color: white;
            border-left: 4px solid #3498db;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card h3 {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        .stat-card .number {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
        }
        .revenue { border-top: 4px solid #27ae60; }
        .sales { border-top: 4px solid #3498db; }
        .products { border-top: 4px solid #e74c3c; }
        .users { border-top: 4px solid #f39c12; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #2c3e50;
        }
        table tr:hover {
            background: #f8f9fa;
        }
        .positive { color: #27ae60; font-weight: bold; }
        .warning { color: #f39c12; font-weight: bold; }
        .danger { color: #e74c3c; font-weight: bold; }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ecf0f1;
        }
        .card-header h3 {
            color: #2c3e50;
            margin: 0;
        }
        .progress-bar {
            width: 100%;
            height: 8px;
            background: #ecf0f1;
            border-radius: 4px;
            overflow: hidden;
            margin-top: 5px;
        }
        .progress-fill {
            height: 100%;
            background: #27ae60;
            transition: width 0.3s;
        }
        .stock-low { background: #e74c3c; }
        .stock-medium { background: #f39c12; }
        .stock-high { background: #27ae60; }
        .section-title {
            color: #2c3e50;
            margin: 30px 0 15px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #3498db;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>Vending Machine</h2>
            <p>Admin Dashboard</p>
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php">Dashboard</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="sales.php" class="active">Sales</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Sales Report & Analytics</h1>
            <p>Comprehensive overview of your vending machine performance</p>
        </div>

        <!-- Key Metrics -->
        <div class="stats-grid">
            <div class="stat-card revenue">
                <h3>Total Revenue</h3>
                <div class="number"><?php echo number_format($total_sales, 2); ?> Tk</div>
                <p style="color: #7f8c8d; font-size: 12px; margin-top: 5px;">Lifetime earnings</p>
            </div>
            <div class="stat-card sales">
                <h3>Products Sold</h3>
                <div class="number"><?php echo $total_products_sold; ?></div>
                <p style="color: #7f8c8d; font-size: 12px; margin-top: 5px;">Total units sold</p>
            </div>
            <div class="stat-card products">
                <h3>Active Products</h3>
                <div class="number"><?php echo count($product_sales_data); ?></div>
                <p style="color: #7f8c8d; font-size: 12px; margin-top: 5px;">In inventory</p>
            </div>
            <div class="stat-card users">
                <h3>Active Users</h3>
                <div class="number"><?php echo $recent_users->num_rows; ?></div>
                <p style="color: #7f8c8d; font-size: 12px; margin-top: 5px;">Registered customers</p>
            </div>
        </div>

        <!-- Product Performance -->
        <div class="card">
            <div class="card-header">
                <h3>Product Performance</h3>
                <span style="color: #7f8c8d; font-size: 14px;">Revenue breakdown by product</span>
            </div>
            
            <?php if (count($product_sales_data) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Initial Stock</th>
                            <th>Current Stock</th>
                            <th>Units Sold</th>
                            <th>Revenue</th>
                            <th>Stock Level</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($product_sales_data as $product): 
                            $stock_percentage = ($product['current_stock'] / $product['initial_stock']) * 100;
                            $stock_class = $stock_percentage < 20 ? 'stock-low' : ($stock_percentage < 50 ? 'stock-medium' : 'stock-high');
                        ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($product['name']); ?></strong></td>
                            <td class="positive"><?php echo number_format($product['price'], 2); ?> Tk</td>
                            <td><?php echo $product['initial_stock']; ?></td>
                            <td>
                                <?php if ($product['current_stock'] == 0): ?>
                                    <span class="danger">Out of Stock</span>
                                <?php else: ?>
                                    <?php echo $product['current_stock']; ?>
                                <?php endif; ?>
                            </td>
                            <td class="positive"><?php echo $product['sold']; ?></td>
                            <td class="positive"><?php echo number_format($product['revenue'], 2); ?> Tk</td>
                            <td style="width: 120px;">
                                <div class="progress-bar">
                                    <div class="progress-fill <?php echo $stock_class; ?>" style="width: <?php echo $stock_percentage; ?>%"></div>
                                </div>
                                <small style="color: #7f8c8d;"><?php echo number_format($stock_percentage, 1); ?>%</small>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 40px; color: #7f8c8d;">
                    <h3>No Sales Data Available</h3>
                    <p>Sales information will appear here once products are sold.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Recent User Activity -->
        <div class="card">
            <div class="card-header">
                <h3>Recent User Activity</h3>
                <span style="color: #7f8c8d; font-size: 14px;">Latest registered users</span>
            </div>
            
            <?php if ($recent_users->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Phone</th>
                            <th>Balance</th>
                            <th>Join Date</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($user = $recent_users->fetch_assoc()): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($user['name']); ?></strong></td>
                            <td><?php echo htmlspecialchars($user['phone']); ?></td>
                            <td class="positive"><?php echo number_format($user['balance'], 2); ?> Tk</td>
                            <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                            <td>
                                <span style="background: #27ae60; color: white; padding: 4px 8px; border-radius: 12px; font-size: 12px;">
                                    Active
                                </span>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div style="text-align: center; padding: 20px; color: #7f8c8d;">
                    <p>No users registered yet.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Summary -->
        <div class="card">
            <h3 class="section-title">Performance Summary</h3>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div>
                    <h4 style="color: #2c3e50; margin-bottom: 10px;">Top Performing Product</h4>
                    <?php if (count($product_sales_data) > 0): 
                        $top_product = $product_sales_data[0];
                    ?>
                        <p style="font-size: 18px; color: #27ae60; font-weight: bold;">
                            <?php echo $top_product['name']; ?>
                        </p>
                        <p style="color: #7f8c8d;">
                            Revenue: <?php echo number_format($top_product['revenue'], 2); ?> Tk | 
                            Sold: <?php echo $top_product['sold']; ?> units
                        </p>
                    <?php else: ?>
                        <p style="color: #7f8c8d;">No sales data available</p>
                    <?php endif; ?>
                </div>
                <div>
                    <h4 style="color: #2c3e50; margin-bottom: 10px;">Inventory Health</h4>
                    <?php
                    $out_of_stock = 0;
                    $low_stock = 0;
                    foreach($product_sales_data as $product) {
                        if ($product['current_stock'] == 0) $out_of_stock++;
                        elseif ($product['current_stock'] < 5) $low_stock++;
                    }
                    ?>
                    <p style="color: <?php echo $out_of_stock > 0 ? '#e74c3c' : '#27ae60'; ?>; font-weight: bold;">
                        Out of Stock: <?php echo $out_of_stock; ?> products
                    </p>
                    <p style="color: <?php echo $low_stock > 0 ? '#f39c12' : '#27ae60'; ?>; font-weight: bold;">
                        Low Stock: <?php echo $low_stock; ?> products
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
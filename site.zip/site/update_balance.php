<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $userId = $input['user_id'] ?? 0;
    $newBalance = $input['balance'] ?? 0;
    
    if ($userId > 0) {
        $stmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
        $stmt->bind_param("di", $newBalance, $userId);
        
        if ($stmt->execute()) {
            $response = [
                'success' => true,
                'message' => 'User balance updated successfully',
                'new_balance' => $newBalance
            ];
        } else {
            $response = [
                'success' => false,
                'message' => 'Failed to update user balance: ' . $conn->error
            ];
        }
        $stmt->close();
    } else {
        $response = [
            'success' => false,
            'message' => 'Invalid user ID'
        ];
    }
} else {
    $response = [
        'success' => false,
        'message' => 'Invalid request method'
    ];
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get JSON input
    $input = json_decode(file_get_contents('php://input'), true);
    
    $phone = $input['phone'] ?? '';
    $password = $input['password'] ?? '';
    $type = $input['type'] ?? '';
    
    if (empty($phone) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Phone and password are required']);
        exit;
    }
    
    if ($type == 'register') {
        // Check if user already exists
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE phone = ?");
        $check_stmt->bind_param("s", $phone);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $response = [
                'success' => false,
                'message' => 'Phone already registered'
            ];
        } else {
            // Registration
            $name = explode('@', $phone)[0];
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $balance = .00;
            
            $stmt = $conn->prepare("INSERT INTO users (name, phone, password, balance) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("sssd", $name, $phone, $hashedPassword, $balance);
            
            if ($stmt->execute()) {
                $user_id = $stmt->insert_id;
                $response = [
                    'success' => true,
                    'message' => 'Registration successful',
                    'user' => [
                        'id' => $user_id,
                        'name' => $name,
                        'phone' => $phone,
                        'balance' => $balance
                    ]
                ];
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Registration failed'
                ];
            }
            $stmt->close();
        }
        $check_stmt->close();
        
    } else {
        // Login
        $stmt = $conn->prepare("SELECT id, name, phone, password, balance FROM users WHERE phone = ?");
        $stmt->bind_param("s", $phone);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            if (password_verify($password, $user['password'])) {
                $response = [
                    'success' => true,
                    'message' => 'Login successful',
                    'user' => [
                        'id' => $user['id'],
                        'name' => $user['name'],
                        'phone' => $user['phone'],
                        'balance' => $user['balance']
                    ]
                ];
            } else {
                $response = [
                    'success' => false,
                    'message' => 'Invalid password'
                ];
            }
        } else {
            $response = [
                'success' => false,
                'message' => 'User not found'
            ];
        }
        $stmt->close();
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>
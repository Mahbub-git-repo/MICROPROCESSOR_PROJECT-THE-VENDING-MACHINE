<?php
// Set headers first - before any output
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

$message = $data['message'] ?? '';

// Simple response
if (!empty($message)) {
    $response = [
        'status' => 'success',
        'message' => 'Message received!',
        'received_message' => $message,
        'timestamp' => date('Y-m-d H:i:s')
    ];
} else {
    $response = [
        'status' => 'error',
        'message' => 'No message received'
    ];
}

echo json_encode($response);
exit();
?>
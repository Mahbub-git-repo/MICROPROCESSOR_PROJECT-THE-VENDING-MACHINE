<?php
include 'config.php';

$sql = "SELECT id, name, description, price, image, quantity FROM products ORDER BY name";
$result = $conn->query($sql);

$products = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // Build full image URL
        $imageUrl = '';
        if (!empty($row['image'])) {
            $imageUrl = BASE_URL . 'uploads/' . $row['image'];
        } else {
            // Default image if no image specified
            $imageUrl = BASE_URL . 'uploads/default.jpg';
        }
        
        $products[] = [
            'id' => (int)$row['id'],
            'name' => $row['name'],
            'description' => $row['description'],
            'price' => (float)$row['price'],
            'image' => $imageUrl,
            'quantity' => (int)$row['quantity']
        ];
    }
    $response = [
        'success' => true,
        'products' => $products
    ];
} else {
    $response = [
        'success' => false,
        'message' => 'No products found'
    ];
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
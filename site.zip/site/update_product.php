<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $productId = $input['product_id'] ?? 0;
    $quantity = $input['quantity'] ?? 0;
    
    if ($productId > 0) {
        $stmt = $conn->prepare("UPDATE products SET quantity = ? WHERE id = ?");
        $stmt->bind_param("ii", $quantity, $productId);
        
        if ($stmt->execute()) {
            $response = [
                'success' => true,
                'message' => 'Product quantity updated successfully'
            ];
        } else {
            $response = [
                'success' => false,
                'message' => 'Failed to update product quantity: ' . $conn->error
            ];
        }
        $stmt->close();
    } else {
        $response = [
            'success' => false,
            'message' => 'Invalid product ID'
        ];
    }
} else {
    $response = [
        'success' => false,
        'message' => 'Invalid request method'
    ];
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
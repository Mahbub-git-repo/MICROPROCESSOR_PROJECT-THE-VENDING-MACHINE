<?php
// Set headers first - before any output
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit(0);
}

// Simple response to avoid any issues
$response = [
    'status' => 'success',
    'message' => 'PHP Backend is working!',
    'timestamp' => date('Y-m-d H:i:s'),
    'data' => [
        'server' => 'InfinityFree',
        'php_version' => PHP_VERSION,
        'request_method' => $_SERVER['REQUEST_METHOD']
    ]
];

// Output only JSON
echo json_encode($response);
// Make sure no other output
exit();
?>
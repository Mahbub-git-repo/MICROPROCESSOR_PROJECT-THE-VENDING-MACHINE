<?php
require 'config1.php';
requireLogin();

// Get statistics
$users_count = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
$products_count = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
$total_sales = $conn->query("SELECT SUM(price) as total FROM products")->fetch_assoc()['total'] ?? 0;
$low_stock = $conn->query("SELECT COUNT(*) as count FROM products WHERE quantity < 5")->fetch_assoc()['count'];

// Recent users
$recent_users = $conn->query("SELECT name, phone, balance, created_at FROM users ORDER BY created_at DESC LIMIT 5");

// Low stock products
$low_stock_products = $conn->query("SELECT name, quantity, price FROM products WHERE quantity < 5 ORDER BY quantity ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Vending Machine</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            color: #333;
        }
        .sidebar {
            width: 250px;
            background: #2c3e50;
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
        }
        .sidebar-header {
            padding: 0 20px 20px;
            border-bottom: 1px solid #34495e;
            margin-bottom: 20px;
        }
        .sidebar-header h2 {
            color: #3498db;
        }
        .nav-links {
            list-style: none;
        }
        .nav-links li a {
            display: block;
            padding: 15px 20px;
            color: #bdc3c7;
            text-decoration: none;
            transition: all 0.3s;
        }
        .nav-links li a:hover, .nav-links li a.active {
            background: #34495e;
            color: white;
            border-left: 4px solid #3498db;
        }
        .main-content {
            margin-left: 250px;
            padding: 20px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .stat-card h3 {
            color: #7f8c8d;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .stat-card .number {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
        }
        .card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card-header {
            display: flex;
            justify-content: between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #ecf0f1;
        }
        .card-header h3 {
            color: #2c3e50;
        }
        .btn {
            padding: 8px 16px;
            background: #3498db;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-danger { background: #e74c3c; }
        .btn-success { background: #27ae60; }
        .btn-warning { background: #f39c12; }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }
        table th {
            background: #f8f9fa;
            font-weight: 600;
        }
        .low-stock { color: #e74c3c; font-weight: bold; }
        .in-stock { color: #27ae60; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>Vending Machine</h2>
            <p>Admin Dashboard</p>
        </div>
        <ul class="nav-links">
            <li><a href="dashboard.php" class="active">Dashboard</a></li>
            <li><a href="products.php">Products</a></li>
            <li><a href="users.php">Users</a></li>
            <li><a href="sales.php">Sales</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <div class="header">
            <h1>Dashboard Overview</h1>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>TOTAL USERS</h3>
                <div class="number"><?php echo $users_count; ?></div>
            </div>
            <div class="stat-card">
                <h3>TOTAL PRODUCTS</h3>
                <div class="number"><?php echo $products_count; ?></div>
            </div>
            <div class="stat-card">
                <h3>TOTAL SALES VALUE</h3>
                <div class="number"><?php echo number_format($total_sales, 2); ?> Tk</div>
            </div>
            <div class="stat-card">
                <h3>LOW STOCK ITEMS</h3>
                <div class="number"><?php echo $low_stock; ?></div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Recent Users</h3>
                <a href="users.php" class="btn">View All</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Balance</th>
                        <th>Joined</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($user = $recent_users->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                        <td><?php echo htmlspecialchars($user['phone']); ?></td>
                        <td><?php echo number_format($user['balance'], 2); ?> Tk</td>
                        <td><?php echo date('M j, Y', strtotime($user['created_at'])); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>

        <div class="card">
            <div class="card-header">
                <h3>Low Stock Alert</h3>
                <a href="products.php" class="btn btn-warning">Manage Products</a>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($product = $low_stock_products->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td class="low-stock"><?php echo $product['quantity']; ?></td>
                        <td><?php echo number_format($product['price'], 2); ?> Tk</td>
                        <td>
                            <?php if ($product['quantity'] == 0): ?>
                                <span class="low-stock">Out of Stock</span>
                            <?php else: ?>
                                <span class="low-stock">Low Stock</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                    <?php if ($low_stock_products->num_rows == 0): ?>
                    <tr>
                        <td colspan="4" style="text-align: center;">All products are well stocked! 🎉</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>
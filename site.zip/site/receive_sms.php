<?php
// receive_sms.php - COMPLETE WORKING VERSION
include 'config1.php';

// Log everything
file_put_contents('sms_log.txt', "=== " . date('Y-m-d H:i:s') . " ===\n", FILE_APPEND);

// Try all possible parameter names
$possibleKeys = ['message', 'text', 'body', 'content', 'sms', 'msg'];
$smsContent = '';

foreach ($possibleKeys as $key) {
    if (!empty($_POST[$key])) {
        $smsContent = $_POST[$key];
        file_put_contents('sms_log.txt', "Found in POST['$key']: $smsContent\n", FILE_APPEND);
        break;
    }
}

// If still empty, check raw input
if (empty($smsContent)) {
    $rawInput = file_get_contents('php://input');
    file_put_contents('sms_log.txt', "Raw input: $rawInput\n", FILE_APPEND);
    
    if (!empty($rawInput)) {
        // Try to parse as JSON
        $jsonData = json_decode($rawInput, true);
        if ($jsonData) {
            foreach ($possibleKeys as $key) {
                if (!empty($jsonData[$key])) {
                    $smsContent = $jsonData[$key];
                    file_put_contents('sms_log.txt', "Found in JSON['$key']: $smsContent\n", FILE_APPEND);
                    break;
                }
            }
        }
        
        // If still empty, use raw input
        if (empty($smsContent) && !empty($rawInput)) {
            $smsContent = $rawInput;
            file_put_contents('sms_log.txt', "Using raw input: $smsContent\n", FILE_APPEND);
        }
    }
}

if (!empty($smsContent)) {
    // Process the SMS
    $pattern = '/You have received Tk\s+([0-9]+\.?[0-9]*)\s+from\s+([0-9]{11,15})/i';
    
    if (preg_match($pattern, $smsContent, $matches)) {
        $amount = floatval($matches[1]);
        $phone = trim($matches[2]);
        
        file_put_contents('sms_log.txt', "Processing - Amount: $amount, Phone: $phone\n", FILE_APPEND);
        
        // UPDATE DATABASE - THIS IS THE MISSING PART
        $stmt = $conn->prepare("SELECT id, name, balance FROM users WHERE phone = ?");
        $stmt->bind_param("s", $phone);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $userId = $user['id'];
            $currentBalance = $user['balance'];
            $newBalance = $currentBalance + $amount;
            
            // Update the balance
            $updateStmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
            $updateStmt->bind_param("di", $newBalance, $userId);
            
            if ($updateStmt->execute()) {
                // Log successful update
                $logMessage = "SUCCESS: Balance updated - User: {$user['name']} (ID: $userId), Phone: $phone, Amount: $amount, Old Balance: $currentBalance, New Balance: $newBalance";
                file_put_contents('sms_log.txt', $logMessage . "\n", FILE_APPEND);
                
                // Also log to transaction log
                file_put_contents('transaction_log.txt', date('Y-m-d H:i:s') . " - " . $logMessage . "\n", FILE_APPEND);
                
                http_response_code(200);
                echo "SUCCESS: Balance updated. Added $amount Tk to {$user['name']}. New balance: $newBalance Tk";
            } else {
                $error = "Database update failed: " . $conn->error;
                file_put_contents('sms_log.txt', "ERROR: $error\n", FILE_APPEND);
                file_put_contents('error_log.txt', date('Y-m-d H:i:s') . " - $error\n", FILE_APPEND);
                http_response_code(500);
                echo "ERROR: $error";
            }
            
            $updateStmt->close();
        } else {
            $error = "User not found with phone number: $phone";
            file_put_contents('sms_log.txt', "ERROR: $error\n", FILE_APPEND);
            file_put_contents('error_log.txt', date('Y-m-d H:i:s') . " - $error\n", FILE_APPEND);
            http_response_code(404);
            echo "ERROR: $error - Please register this phone number first";
        }
        
        $stmt->close();
    } else {
        file_put_contents('sms_log.txt', "INFO: Not a payment SMS or format not recognized\n", FILE_APPEND);
        http_response_code(200);
        echo "INFO: Not a payment SMS";
    }
} else {
    file_put_contents('sms_log.txt', "ERROR: No SMS content received\n", FILE_APPEND);
    http_response_code(400);
    echo "ERROR: No SMS content received";
}

file_put_contents('sms_log.txt', "Response sent\n\n", FILE_APPEND);
$conn->close();
?>